package ar.org.centro8.dispositivos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ColegioApplicationTests {

	@Test
	void contextLoads() {
	}

}
