package ar.org.centro8.dispositivos.controllers;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.dispositivos.entities.Curso;
import ar.org.centro8.dispositivos.repositories.CursoRepository;


@Controller
public class ControllerCursos {

    @Autowired
    private CursoRepository cr;

    private String mensaje = "Ingrese un curso !";

    @GetMapping("/cursos1")
    public String getCursos(Model model) {
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("curso", new Curso());
        model.addAttribute("listaCurso", cr.findAll()); // Agregar la lista de cursos al modelo
        return "Cursos";
   // public String getCursos(Model model) {
        // dr.findAll().forEach(System.out::println);
     //   model.addAttribute("mensaje", mensaje);
       // model.addAttribute("curso", new Curso());
        //return "Cursos";
    }

    @GetMapping("/cursos")
    public String cursos(
    @RequestParam(name = "titulo", defaultValue = "", required = false) String titulo,
    @RequestParam(name = "profesor", defaultValue = "", required = false) String profesor,
    Model model
) {
    model.addAttribute("listaCurso", ((List<Curso>) cr.findAll())
        .stream()
        .filter(d -> d.getTitulo().toLowerCase().contains(titulo.toLowerCase()))
        .filter(d -> profesor.isEmpty() || d.getProfesor().toLowerCase().contains(profesor.toLowerCase()))
        .collect(Collectors.toList())
    );
    return "Cursos";
    //public String cursos(
      //  @RequestParam(name="titulo", defaultValue = "", required = false) String titulo,
        //@RequestParam(name="prefesor",defaultValue = "", required = false) String profesor,
          //  Model model
            //){
        //model.addAttribute("lista", dr.findAll());
        //select * from dispositivos where apellido like '%apellido%'
       // model.addAttribute("listaCurso", ((List<Curso>)cr.findAll())
               // .stream()
                //.filter(d->d.getTitulo().toLowerCase().contains(titulo.toLowerCase()))
                //.filter(d->!curso.equalsIgnoreCase("otro curso")
                       // && d.getIdCurso().contains(curso.toLowerCase()))        
       // );
       // return "curso";
    }

    @PostMapping("/saveCurso")
    public String save(@ModelAttribute Curso curso) {
        cr.save(curso);
        if (curso.getId() > 0) {
            mensaje = "Se guardó el curso con id: " + curso.getId() + "!";
        } else {
            mensaje = "No se pudo guardar el curso";
        }
        return "redirect:/cursos1"; // Redirigir a la página de cursos
    //public String save(@ModelAttribute Curso dispositivo) {
        //System.out.println("******************************************");
        //System.out.println(dispositivo);
        //System.out.println("******************************************");
        // dispositivo.setId(0);
       // cr.save(dispositivo);
        //if (dispositivo.getId() > 0) {
          //  mensaje = "Se guardo el curso con id: " + dispositivo.getId() + "!";
       // } else {
         //   mensaje = "No se pudo guardar el curso";
        //}
        //return "Cursos:";
    }
}
