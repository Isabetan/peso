package ar.org.centro8.dispositivos.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ar.org.centro8.dispositivos.entities.Alumno;
import ar.org.centro8.dispositivos.entities.Curso;
import ar.org.centro8.dispositivos.repositories.AlumnoRepository;
import ar.org.centro8.dispositivos.repositories.CursoRepository;

@RestController
@RequestMapping("/api")
public class ColegioRest {

    @Autowired
    private AlumnoRepository dr;
    private CursoRepository cr;

    @GetMapping("/lista")
	public List<Alumno> lista(){
		return (List<Alumno>)dr.findAll();
	}

     @GetMapping("/listaCurso")
	public List<Curso> listaCurso(){
		return (List<Curso>)cr.findAll();
	}
}
