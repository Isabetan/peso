package ar.org.centro8.dispositivos.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import ar.org.centro8.dispositivos.entities.Alumno;

@Repository
public interface AlumnoRepository 
            extends CrudRepository<Alumno, Integer> {
    
}
