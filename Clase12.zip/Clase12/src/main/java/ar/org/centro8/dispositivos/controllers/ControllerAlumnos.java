package ar.org.centro8.dispositivos.controllers;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.dispositivos.entities.Alumno;
import ar.org.centro8.dispositivos.repositories.AlumnoRepository;


@Controller
public class ControllerAlumnos {

    @Autowired
    private AlumnoRepository ar;

    private String mensaje = "Ingrese un alumno !";

    @GetMapping("/")
    public String getAlumno(Model model) {
        // dr.findAll().forEach(System.out::println);
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("dispositivo", new Alumno());
        return "Alumnos";
    }

    @GetMapping("/alumnos")
    public String alumnos(
        @RequestParam(name="nombre", defaultValue = "", required = false) String nombre,
        @RequestParam(name="curso",defaultValue = "", required = false) String curso,
            Model model
            ){
        //model.addAttribute("lista", dr.findAll());
        //select * from dispositivos where apellido like '%apellido%'
        model.addAttribute("lista", ((List<Alumno>)ar.findAll())
                .stream()
                .filter(d->d.getNombre().toLowerCase().contains(nombre.toLowerCase()))
                //.filter(d->!curso.equalsIgnoreCase("otro curso")
                       // && d.getIdCurso().contains(curso.toLowerCase()))        
        );
        return "Alumnos";
    }

    @PostMapping("/saveAlumno")
    public String save(@ModelAttribute Alumno dispositivo) {
        //System.out.println("******************************************");
        //System.out.println(dispositivo);
        //System.out.println("******************************************");
        // dispositivo.setId(0);
        ar.save(dispositivo);
        if (dispositivo.getId() > 0) {
            mensaje = "Se guardo el alumno con id: " + dispositivo.getId() + "!";
        } else {
            mensaje = "No se pudo guardar el alumno";
        }
        return "Alumnos:";
    }

}
